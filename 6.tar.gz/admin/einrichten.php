<?php
/**
 * einrichten.php — einmalige Einrichtung des Adminbereichs.
 *
 * Setzt das Passwort (nur als Hash gespeichert, außerhalb von httpdocs) und
 * legt beim ersten Mal die Projektdatei aus start-projekte.json an.
 *
 * Sobald ein Zugang besteht, verweigert diese Datei den Dienst.
 * Trotzdem: nach der Einrichtung per FTP löschen.
 */

declare(strict_types=1);
require __DIR__ . '/kern.php';

sitzung_starten();
kopfzeilen();

const MIN_ZEICHEN = 12;

$fertig = false;
$meldung = '';
$art = 'schlecht';

if (zugang_vorhanden()) {
    $meldung = 'Es ist bereits ein Passwort gesetzt. Diese Seite tut nichts mehr — '
        . 'bitte die Datei admin/einrichten.php per FTP löschen. '
        . 'Passwort vergessen? Dann die Datei zugang.json im Datenordner löschen '
        . 'und diese Seite erneut aufrufen.';
    $art = 'warnung';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $eins = (string)($_POST['passwort'] ?? '');
    $zwei = (string)($_POST['wiederholung'] ?? '');

    if (!token_pruefen()) {
        $meldung = 'Das Formular war abgelaufen. Bitte noch einmal.';
    } elseif (mb_strlen($eins) < MIN_ZEICHEN) {
        $meldung = 'Das Passwort muss mindestens ' . MIN_ZEICHEN . ' Zeichen haben.';
    } elseif ($eins !== $zwei) {
        $meldung = 'Die beiden Eingaben sind nicht gleich.';
    } elseif (!is_writable(daten_ordner())) {
        $meldung = 'Der Datenordner ' . h(daten_ordner()) . ' ist nicht beschreibbar. '
            . 'Bitte in Plesk oder per FTP anlegen und Schreibrechte geben.';
    } else {
        $zugang = json_encode([
            'hash'     => password_hash($eins, PASSWORD_DEFAULT),
            'angelegt' => date('c'),
        ], JSON_UNESCAPED_SLASHES);

        if (!schreiben_sicher(pfad_zugang(), (string)$zugang)) {
            $meldung = 'Die Zugangsdatei ließ sich nicht schreiben.';
        } else {
            // Startbestand anlegen, falls noch keine Projektdatei da ist
            if (!is_file(pfad_daten()) && is_readable(__DIR__ . '/start-projekte.json')) {
                $start = json_decode((string)file_get_contents(__DIR__ . '/start-projekte.json'), true);
                if (is_array($start['projekte'] ?? null)) {
                    projekte_speichern($start['projekte']);
                }
            }
            $fertig = true;
        }
    }
}

?><!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Adminbereich einrichten – Spektrum</title>
<link rel="stylesheet" href="admin.css">
<link rel="icon" href="../favicon.ico" sizes="any">
</head>
<body>
<main class="anmeldung anmeldung--breit">

<?php if ($fertig): ?>

  <h1>Fertig</h1>
  <p class="meldung meldung--gut">Das Passwort ist gesetzt.</p>
  <ol class="schritte">
    <li>Diese Datei jetzt per FTP löschen: <code>admin/einrichten.php</code></li>
    <li>Danach geht es hier weiter: <a href="index.php">zum Adminbereich</a></li>
  </ol>
  <p class="tipp">Gespeichert wurde nur ein nicht rückrechenbarer Hash des Passworts,
     in <code><?= h(pfad_zugang()) ?></code>.</p>

<?php else: ?>

  <h1>Adminbereich einrichten</h1>
  <p class="unter">Spektrum Bildungszentrum Solingen e.V. — einmalig, danach löschen.</p>

  <?php if ($meldung !== ''): ?>
    <p class="meldung meldung--<?= h($art) ?>"><?= h($meldung) ?></p>
  <?php endif; ?>

  <?php if (!zugang_vorhanden()): ?>
    <p class="tipp">Denk dir ein Passwort aus, das du sonst nirgends benutzt — mindestens
       <?= MIN_ZEICHEN ?> Zeichen. Am besten drei bis vier zufällige Wörter hintereinander.
       Es wird nicht im Klartext gespeichert und lässt sich nicht auslesen; wer es verliert,
       löscht <code>zugang.json</code> im Datenordner und richtet neu ein.</p>

    <form method="post" autocomplete="off">
      <input type="hidden" name="token" value="<?= h(token()) ?>">
      <label for="passwort">Passwort</label>
      <input type="password" id="passwort" name="passwort" required minlength="<?= MIN_ZEICHEN ?>"
             autofocus autocomplete="new-password">
      <label for="wiederholung">Noch einmal</label>
      <input type="password" id="wiederholung" name="wiederholung" required minlength="<?= MIN_ZEICHEN ?>"
             autocomplete="new-password">
      <button type="submit" class="knopf">Passwort setzen</button>
    </form>

    <p class="tipp">Datenordner: <code><?= h(daten_ordner()) ?></code>
       <?= is_writable(daten_ordner()) ? '(beschreibbar ✓)' : '(NICHT beschreibbar ✗)' ?></p>
  <?php else: ?>
    <p><a href="index.php">Zum Adminbereich</a></p>
  <?php endif; ?>

<?php endif; ?>

<p class="fusszeile"><a href="../index.html">Zurück zur Website</a></p>
</main>
</body>
</html>
