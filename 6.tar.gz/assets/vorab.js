document.documentElement.className+=" js";
